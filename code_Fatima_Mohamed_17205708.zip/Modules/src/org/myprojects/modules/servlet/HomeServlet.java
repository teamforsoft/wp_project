package org.myprojects.modules.servlet;
 
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.myprojects.modules.utils.FileLoader;
import org.myprojects.modules.utils.LoginClass;
import org.myprojects.modules.utils.MaintainModule;
import org.myprojects.modules.utils.Search;
 
@WebServlet(urlPatterns = { "/home"})
public class HomeServlet extends HttpServlet {
   private static final long serialVersionUID = 1L;
 
   public HomeServlet() {
       super();
   }
 
   @Override
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
	   RequestDispatcher dispatcher;
	   String pageFrom = request.getParameter("page");
	   String action = request.getParameter("action");
	   if(action !=null) {
		   if(action.equals("edit")) {
			try {
				MaintainModule.EditModuleGet(request, response);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		   }
		   else
		  if(action.equals("delete"))
		   {
				   try {
						MaintainModule.DeleteModuleGet(request, response);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		   }
	   }else
	   if ((pageFrom==null )|| (pageFrom.equals("home") ))
	   {
		   String goSearch = request.getParameter("go");
		   if ((goSearch==null))
			   dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/homeView.jsp");
		   else
			   dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/searchResultsView.jsp");
		   dispatcher.forward(request, response);
	   }else if(pageFrom.equals("searchLoadFile")) {
		   
			String relativeWebPath = "/WEB-INF/resources/modules.csv";
			InputStream input = getServletContext().getResourceAsStream(relativeWebPath);
			try {
				FileLoader.LoadFile(input);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	 
		   dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/searchResultsView.jsp");
		   dispatcher.forward(request, response);
	   }
	   else {
		   if(pageFrom.equals("login"))
			   dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/loginView.jsp");
		   else
			   if(pageFrom.equals("logout"))
			   {
					HttpSession session = request.getSession(true);  
					session.setAttribute("Admin", false);
				   dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/loginView.jsp");
			   }
			   else
				   dispatcher = this.getServletContext().getRequestDispatcher("/WEB-INF/views/searchView.jsp");
		   
		   dispatcher.forward(request, response);
	   }
        
   }
 
   @Override
   protected void doPost(HttpServletRequest request, HttpServletResponse response)
           throws ServletException, IOException {
		HttpSession session = request.getSession(true);
		if(null==session.getAttribute("Admin"))
			session.setAttribute("Admin", false);  
	   String pageFrom = request.getParameter("PageFrom");
	   if(pageFrom.equals("search"))
	   {
		   try {
			Search.SearchPost(request, response, this);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   }else 
		   if((pageFrom.equals("edit"))){
			   try {
				   MaintainModule.EditModulePost(request, response, this);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   
		   }else 
			   if((pageFrom.equals("delete"))){
				   try {
					   MaintainModule.DeleteModuleGet(request, response);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				   
			   }
		   else
		   {
		     String loginId=request.getParameter("loginId");  
		     String password=request.getParameter("password");  
		          
		        try {
					if(LoginClass.VerifyUser(loginId,password) != null){  
						session.setAttribute("Admin", true);  
					       RequestDispatcher dispatcher = request.getServletContext()
					               .getRequestDispatcher("/WEB-INF/views/homeView.jsp");
					       dispatcher.forward(request, response);
					}else{  
//		            out.print("sorry, username or password error!");
						request.setAttribute("errorString", "Wrong Name or Passoword. Try again");
					   RequestDispatcher dispatcher = request.getServletContext()
					           .getRequestDispatcher("/WEB-INF/views/loginView.jsp");
					   dispatcher.forward(request, response);
					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}  		   
	   }
	   

   }
 
}