package org.myprojects.modules.beans;

public class Module {
	   private int id;
	   private int year;
	   private int start;
	   private int finish;
	   private String code;
	   private String name;
	   private String classification;
	   private String day;
	   private boolean active_inactive;
	   private boolean undergraduate;
	   private int stage;
	   private String semester;
	   
	 
	   public Module() {
	 
	   }
	 
	   public Module(String code, String name, String classification, String day, boolean active_inactive, boolean undergraduate, int stage, String semester, int id, int year, int start, int finish) {
	       this.code = code;
	       this.name = name;
	       this.id = id;
	       this.year=year;
	       this.start=start;
	       this.finish=finish;
	       this.classification=classification;
	       this.day=day;
	       this.active_inactive=active_inactive;
	       this.undergraduate=undergraduate;
	       this.stage=stage;
	       this.semester=semester;
	   }
	 
	   public String getCode() {
	       return code;
	   }
	 
	   public void setCode(String code) {
	       this.code = code;
	   }
	 
	   public String getName() {
	       return name;
	   }
	 
	   public void setName(String name) {
	       this.name = name;
	   }
	 
	   public int getId() {
	       return id;
	   }
	 
	   public void setId(int id) {
		   this.id = id;
	   }

	   public int getYear() {
	       return year;
	   }
	 
	   public void setYear(int year) {
	       this.year = year;
	   }
	   public int getStart() {
	       return start;
	   }
	 
	   public void setStart(int start) {
	       this.start = start;
	   }
	   public int getFinish() {
	       return finish;
	   }
	 
	   public void setFinish(int finish) {
	       this.finish = finish;
	   }
	   public String getClassification() {
	       return classification;
	   }
	 
	   public void setClassification(String classification) {
	       this.classification = classification;
	   }
	   public int getStage() {
	       return stage;
	   }
	 
	   public void setStage(int stage) {
	       this.stage = stage;
	   }
	   public String getDay() {
	       return day;
	   }
	 
	   public void setDay(String day) {
	       this.day = day;
	   }
	   public boolean getActive_inactive() {
	       return active_inactive;
	   }
	 
	   public void setActive_inactive(boolean active_inactive) {
	       this.active_inactive = active_inactive;
	   }
	   public boolean getUndergraduate() {
	       return undergraduate;
	   }
	 
	   public void setUndergraduate(boolean undergraduate) {
	       this.undergraduate = undergraduate;
	   }
	   public String getSemester() {
	       return semester;
	   }
	 
	   public void setSemester(String semester) {
		   this.semester=semester;
	   }
	   
}
