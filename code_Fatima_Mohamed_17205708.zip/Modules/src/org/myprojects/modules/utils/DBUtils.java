package org.myprojects.modules.utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
 
import org.myprojects.modules.beans.Module;
import org.myprojects.modules.beans.TimeTable;

 
public class DBUtils {
 
 
    public static List<Module> queryModule(Connection conn,int stageSrch,int yearSrch,String semesterSrch) throws SQLException {
        String sql = "Select code, name, id, undergraduate, year, semester, active_inactive, classification, day, start, finish, stage from javapro.module2  Where "
        		+ "stage =  ? "
        		+ "And year = ? "
        		+ "And semester = ? ";
        
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
 
        preparedStatement.setInt(1, stageSrch);
        preparedStatement.setInt(2, yearSrch);
        preparedStatement.setString(3, semesterSrch);
        ResultSet rs = preparedStatement.executeQuery();
        
        List<Module> list = new ArrayList<Module>();
        while (rs.next()) {
            String code = rs.getString("code");
            String name = rs.getString("name");
            int id = rs.getInt("id");
            boolean undergraduate = rs.getBoolean("undergraduate");
            int year = rs.getInt("year");
            String semester = rs.getString("semester");
            boolean active_inactive = rs.getBoolean("active_inactive");
            String classification = rs.getString("classification");
            String day = rs.getString("day");
            int start = rs.getInt("start");
            int finish = rs.getInt("finish");
            int stage = rs.getInt("stage");

            
            Module Module = new Module();
            Module.setCode(code);
            Module.setName(name);
            Module.setId(id);
            Module.setUndergraduate(undergraduate);
            Module.setClassification(classification);
            Module.setDay(day);
            Module.setStart(start);
            Module.setFinish(finish);
            Module.setStage(stage);
            Module.setActive_inactive(active_inactive);
            Module.setYear(year);
            Module.setSemester(semester);
            list.add(Module);
        }
        return list;
    }
    public static Module findModule(Connection conn,int Id) throws SQLException {
        String sql = "Select code, name, id, undergraduate, year, semester, active_inactive, classification, day, start, finish, stage from javapro.module2  Where "
        		+ "Id =   ?";
          
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
 
        preparedStatement.setInt(1, Id);
        ResultSet rs = preparedStatement.executeQuery();
        Module module = new Module();
        if(rs.next())
        {
	        String code = rs.getString("code");
	        String name = rs.getString("name");
	        int id = rs.getInt("id");
	        boolean undergraduate = rs.getBoolean("undergraduate");
	        int year = rs.getInt("year");
	        String semester = rs.getString("semester");
	        boolean active_inactive = rs.getBoolean("active_inactive");
	        String classification = rs.getString("classification");
	        String day = rs.getString("day");
	        int start = rs.getInt("start");
	        int finish = rs.getInt("finish");
	        int stage = rs.getInt("stage");
        

        
        module.setCode(code);
        module.setName(name);
        module.setId(id);
        module.setUndergraduate(undergraduate);
        module.setClassification(classification);
        module.setDay(day);
        module.setStart(start);
        module.setFinish(finish);
        module.setStage(stage);
        module.setActive_inactive(active_inactive);
        module.setYear(year);
        module.setSemester(semester);
        }
        return module;
    }

    public static void updateModule(Connection conn, Module Module) throws SQLException {
        String sql = "Update module2 Set name =?, code=?, stage=?, undergraduate=?, semester=?, active_inactive=?, classification=?, day=?, start=?, finish=? Where Id = ? ";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setString(1, Module.getName());
        //pstm.setFloat(2, Module.getRoomNo());
        pstm.setInt(3, Module.getStage());
        pstm.setString(2, Module.getCode());
        pstm.setString(5, Module.getSemester());
        pstm.setInt(9, Module.getStart());
        pstm.setInt(10, Module.getFinish());
        pstm.setString(7, Module.getClassification());
        pstm.setBoolean(4, Module.getUndergraduate());
        pstm.setBoolean(6, Module.getActive_inactive());
        pstm.setString(8, Module.getDay());
        pstm.setInt(11, Module.getId());
        
        pstm.executeUpdate();
    }
 
    public static void insertModule(Connection conn, Module Module) throws SQLException {
        String sql = "Insert into module(code, name, room_no, lecturer) values (?,?,?,?)";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setString(1, Module.getName());
        //pstm.setFloat(2, Module.getRoomNo());
       // pstm.setString(3, Module.getLecturer());
        pstm.setString(4, Module.getCode());
        pstm.executeUpdate();
    }
 
    public static void deleteModule(Connection conn, int id) throws SQLException {
        String sql = "Delete From module2 where id= ?";
 
        PreparedStatement pstm = conn.prepareStatement(sql);
 
        pstm.setInt(1, id);
 
        pstm.executeUpdate();
    
    }
    public static List<TimeTable> queryTimeTable(Connection conn,int stageSrch,int yearSrch,String semesterSrch) throws SQLException {
        String sql = "SELECT start, day,group_concat(distinct code separator ' / ') as theText ,c.class_name " + 
        		"from javapro.module2 m " + 
        		"inner join javapro.classifications c on m.classification=c.class_code " + 
        		"where stage= ? " + 
        		"and semester= ? " + 
        		"and year= ? " +
        		"group by start,day " + 
        		"order by start,day";
        
        PreparedStatement preparedStatement = conn.prepareStatement(sql);
 
        preparedStatement.setInt(1, stageSrch);
        preparedStatement.setInt(3, yearSrch);
        preparedStatement.setString(2, semesterSrch);
        ResultSet rs = preparedStatement.executeQuery();
        
        String currentTime = "";
        
        List<TimeTable> list = new ArrayList<TimeTable>();
        TimeTable timeTable=null;
        String startTime = "";
        String day = "";
        String theText  = "";
        String classification="";
        while (rs.next()) {
            startTime = rs.getString("start");
            day = rs.getString("day");
            classification=rs.getString("class_name");
            theText  = rs.getString("theText") + "<br>"+classification;
            if (!startTime.equals( currentTime))
            {
            	if (!currentTime.equals(""))
            	{
            		timeTable.setStartTime(currentTime);
            		list.add(timeTable);
            		timeTable=new TimeTable();
            	}
            	else
            		timeTable=new TimeTable();
            		
            	currentTime=startTime;
            }
             switch(day) 
            { 
                case "Mon": 
                    timeTable.setMonday(theText);
                    break; 
                    
                case "Tue": 
                	timeTable.setTuesday(theText);
                    break; 
                case "Wed": 
                	timeTable.setWednesday(theText);
                    break; 
                case "Thu": 
                	timeTable.setThursday(theText); 
                    break; 
                case "Fri": 
                	timeTable.setFriday(theText); 
                    break; 
            }             
        }
    	if (!currentTime.equals(""))
    	{
      		timeTable.setStartTime(currentTime);
    		list.add(timeTable);
    	}
        return list;
    }
}