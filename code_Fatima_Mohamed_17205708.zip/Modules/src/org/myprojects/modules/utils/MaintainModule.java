package org.myprojects.modules.utils;
import org.myprojects.modules.beans.Module;
import org.myprojects.modules.conn.ConnectionUtils;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;

//import com.mysql.jdbc.Connection;

public class MaintainModule {
	public static void EditModulePost(HttpServletRequest request, HttpServletResponse response, Servlet servlet) throws ClassNotFoundException, SQLException
	{
		
        Connection conn = ConnectionUtils.getConnection();
        
        String code = (String) request.getParameter("code");
        String name = (String) request.getParameter("name");
        String yearStr = (String) request.getParameter("year");
        String startStr = (String) request.getParameter("start");
        String finishStr = (String) request.getParameter("finish");
        String idStr = (String) request.getParameter("id");
        String stageStr = (String) request.getParameter("stage");
        String active_inactiveStr  = (String) request.getParameter("active_inactive");
        String undergraduateStr  = (String) request.getParameter("undergraduate");
        String day  = (String) request.getParameter("day");
        String semester = (String) request.getParameter("semester");
        String classification = (String) request.getParameter("classification");
  //      String classification=""; 
        boolean active_inactive=false;
        boolean undergraduate=false;
        int stage=0;
        //String semester="";
        int id=0;
        int year=0;
        int start=0;
        int finish=0;     
        try {
        	year = Integer.parseInt(yearStr);
        } catch (Exception e) {
        }
        try {
        	start = Integer.parseInt(startStr);
        } catch (Exception e) {
        }
        try {
        	finish = Integer.parseInt(finishStr);
        } catch (Exception e) {
        }
        try {
        	id = Integer.parseInt(idStr);
        } catch (Exception e) {
        }
        try {
        	stage = Integer.parseInt(stageStr);
        } catch (Exception e) {
        }
        try {
        	active_inactive = Boolean.parseBoolean(active_inactiveStr);
        } catch (Exception e) {
        }
        try {
        	undergraduate = Boolean.parseBoolean(undergraduateStr);
        } catch (Exception e) {
        }
        
        Module module = new Module( code,  name,  classification,  day,  active_inactive,  undergraduate,  stage,  semester,  id,  year,  start,  finish);
 
        String errorString = null;
 
        try {
            DBUtils.updateModule(conn, module);
        } catch (SQLException e) {
            e.printStackTrace();
            errorString = e.getMessage();
        }
        // Store infomation to request attribute, before forward to views.
        request.setAttribute("errorString", errorString);
        request.setAttribute("module", module);
 
        // If error, forward to Edit page.
        if (errorString != null) {
            RequestDispatcher dispatcher = request.getServletContext()
                    .getRequestDispatcher("/WEB-INF/views/editModuleView.jsp");
            try {
				dispatcher.forward(request, response);
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        // If everything nice.
        // Redirect to the product listing page.
        else {
            try {
				response.sendRedirect(request.getContextPath() + "/home");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }	

	}
	public static void EditModuleGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException {
		
		Connection conn = ConnectionUtils.getConnection();
	       
	        String IdStr = (String) request.getParameter("Id");
	        int Id = Integer.parseInt(IdStr);	 
	        Module module = null;
	 
	        String errorString = null;
	 
	        try {
	            module = DBUtils.findModule(conn, Id);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            errorString = e.getMessage();
	        }
	 
	        // If no error.
	        // The product does not exist to edit.
	        // Redirect to productList page.
	        if (errorString != null && module == null) {
	            try {
					response.sendRedirect(request.getServletPath() + "/home?go=search");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            return;
	        }
	 
	        // Store errorString in request attribute, before forward to views.
	        request.setAttribute("errorString", errorString);
	        request.setAttribute("module", module);
	 
	        RequestDispatcher dispatcher = request.getServletContext()
	                .getRequestDispatcher("/WEB-INF/views/editModuleView.jsp");
	        dispatcher.forward(request, response);	}
	public static void DeleteModuleGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, ClassNotFoundException, SQLException {
	     Connection conn = ConnectionUtils.getConnection();
	     
	     String idStr = (String) request.getParameter("Id");
	     int id=0;
	     try {
	        	id = Integer.parseInt(idStr);
	        } catch (Exception e) {
	        }
	     	
	 
	        String errorString = null;
	 
	        try {
	            DBUtils.deleteModule(conn, id);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            errorString = e.getMessage();
	        } 
	         
	        // If has an error, redirects to the error page.
	        if (errorString != null) {
	            // Store the information in the request attribute, before forward to views.
	            request.setAttribute("errorString", errorString);
	            // 
	            RequestDispatcher dispatcher = request.getServletContext()
	                    .getRequestDispatcher("/WEB-INF/views/deleteModuleView.jsp");
	            dispatcher.forward(request, response);
	        }
	        // If everything nice.
	        // Redirect to the product listing page.        
	        else {
	            response.sendRedirect(request.getContextPath() + "/home");
	        }
	
	}
	
}