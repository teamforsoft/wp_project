package org.myprojects.modules.utils;

import java.sql.SQLException;

import org.myprojects.modules.conn.ConnectionUtils;

//import javax.servlet.ServletContext;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginClass
{
	public static String VerifyUser(String loginId, String password) throws IOException, ClassNotFoundException, SQLException {
		String sql = " select name from users where login_id = ? and password= ? ";
		String name=null;
		try { 
				Connection conn = ConnectionUtils.getConnection();
			   	PreparedStatement ps = conn.prepareStatement(sql);
			   	ps.setString(1,loginId);
			   	ps.setString(2,password);

			   	ResultSet rs = ps.executeQuery();
			   	if(rs.next())
			   	{
			   		name=rs.getString(1);
			   	}
         		ps. close();
					
	        } catch (SQLException e) {
 	            e.printStackTrace();
		}finally {}
		return name;
	}
}
		
