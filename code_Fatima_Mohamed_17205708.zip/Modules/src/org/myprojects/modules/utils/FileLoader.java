package org.myprojects.modules.utils;

import java.io.BufferedReader;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.myprojects.modules.conn.ConnectionUtils;

//import javax.servlet.ServletContext;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class FileLoader
{
	public static void LoadFile(InputStream input) throws IOException, ClassNotFoundException, SQLException {
		String sql = " INSERT INTO MODULE2(stage,code,name,semester,classification,day,start,finish,active_inactive,undergraduate,year) VALUES(?,?,?,?,?,?,?,?,?,?,?) ";

		try { 
				Connection conn = ConnectionUtils.getConnection();
		        BufferedReader bReader = new BufferedReader(new InputStreamReader(input));
		        String line = ""; 
		        Boolean firstline=true;
		        while ((line = bReader.readLine()) != null) {
		         try {

		               if (line != null)
				       {
		            	   if(!firstline) {
		            		   String newLine1= line.replaceAll(",,", ",XX,");
		            		   String newLine2= newLine1.replaceAll(",,", ",XX,");
		            		   String[] array = new String[20];
		            		   String regex="(\"[^\"]*\"|[^,]+)";
		            		   Matcher m = Pattern.compile(regex).matcher(newLine2);
		            		   int i=0;
		            		    while (m.find()) {
		            		       array[i] = m.group(0);
		            		       i=i+1;
		            		    }
		            		    //1- read year from
		            		    //String YearInFile= array[19];
		            		    //2-check if YearInFile is already in the database
		            		    Boolean LoadTheFile = true;
		            		    if (!LoadTheFile)
		            		    	return;
		            		    
	            			   	PreparedStatement ps = conn.prepareStatement(sql);
	            			   	ps.setString(1,array[0]);
	            			   	ps.setString(2,array[1]);
			             		ps.setString(3,array[3]);
			             		ps.setString(4,array[7]);
			             		ps.setString(5,array[8]);
			             		ps.setString(6,array[9]);
			             		ps.setString(7,array[10]);
			             		ps.setString(8,array[11]);
			             		ps.setBoolean(9,(Boolean.parseBoolean(array[16])));
			             		ps.setBoolean(10,(Boolean.parseBoolean(array[17])));
			             		ps.setInt(11, (Integer.parseInt(array[18])));
			             		ps.executeUpdate();
			             		ps. close();
		            	   	}else
					    	   firstline=false;
				       }
		         } catch (Exception e) {
				    System.out.println("xxxxxxxxxxxxxxxxxxxxx");
					e.printStackTrace();
		         }		
					
		    }
		} catch (Exception e) {
			
	    	System.out.println("xxxxxxxxxxxxxxxxxxxxx");
	    	e.printStackTrace();
		}finally {}
	}
}
		
