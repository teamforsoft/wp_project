package org.myprojects.modules.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.myprojects.modules.beans.Module;
import org.myprojects.modules.beans.TimeTable;
import org.myprojects.modules.conn.ConnectionUtils;

public class Search {

	public static void SearchPost(HttpServletRequest request, HttpServletResponse response, Servlet servlet) throws ClassNotFoundException, SQLException, ServletException, IOException
	{
		
		HttpSession session = request.getSession(true);
		if(null==session.getAttribute("Admin"))
			session.setAttribute("Admin", false);  

	       String stageStr = (String) request.getParameter("stage");
	       String yearStr = (String) request.getParameter("year");
	       String semester = (String) request.getParameter("semester");
	       String action = (String) request.getParameter("action");
	       
	       String errorString =null;
	       
	       int stage = 0;
	       if(stageStr!=null && !stageStr.isEmpty() )
	       {
		       try {
		           stage = Integer.parseInt(stageStr);
		       } catch (Exception e) {
		    	   errorString="Bad stage";
		       }
	       }
	       if(stage==0)
	    	   errorString="enter stage";
	       int year = 0;
	       
	       if(yearStr!=null && !yearStr.isEmpty() )
	       {
		       try {
		    	   year = Integer.parseInt(yearStr);
		       } catch (Exception e) {
		    	   errorString="Bad year";
		       }
	       }
	       if(year==0)
	    	   errorString="enter year";
	       
	       
	       if(semester.equals(""))
	    	   errorString="enter semester";
	       
	       if (action==null)
	    	   errorString="action not selected";
	       
	       request.setAttribute("errorString", errorString);
	
	       // If error, forward to Edit page.
	       if (errorString != null) {
	           RequestDispatcher dispatcher = request.getServletContext()
	                   .getRequestDispatcher("/WEB-INF/views/searchView.jsp");
	           dispatcher.forward(request, response);
	       }
	       // If everything nice.
	       // Redirect to the product listing page.
	       else {
	 		   	request.setAttribute("action", action);
	 		   	request.setAttribute("stage", stage);
	 		   	request.setAttribute("year", year);
	 		   	request.setAttribute("semester", semester);
	 	        boolean Admin=(boolean) session.getAttribute("Admin"); 
	 	        
	 	        if (Admin)
	 	        {
		 	        List<Module> list = null;
		 	        try {
		 	            Connection conn = ConnectionUtils.getConnection();
	
		 	            list = DBUtils.queryModule(conn,stage,year,semester);
		 	        } catch (SQLException e) {
		 	            e.printStackTrace();
		 	            errorString = e.getMessage();
		 	        }
		 	        catch (ClassNotFoundException e) {
		 	            e.printStackTrace();
		 	            errorString = e.getMessage();
		 	        }// Store info in request attribute, before forward to views
		 	        request.setAttribute("ModuleList", list);
		 	        request.setAttribute("errorString", errorString);
			 	    request.setAttribute("Admin", Admin); 
		 		   	RequestDispatcher dispatcher = request.getServletContext()
			                   .getRequestDispatcher("/WEB-INF/views/searchResultsView.jsp");
			           dispatcher.forward(request, response);
	 	        }else
	 	        {
		 	        List<TimeTable> list = null;
		 	        try {
		 	            Connection conn = ConnectionUtils.getConnection();
	
		 	            list = DBUtils.queryTimeTable(conn,stage,year,semester);
		 	        } catch (SQLException e) {
		 	            e.printStackTrace();
		 	            errorString = e.getMessage();
		 	        }
		 	        catch (ClassNotFoundException e) {
		 	            e.printStackTrace();
		 	            errorString = e.getMessage();
		 	        }        // Store info in request attribute, before forward to views
		 	        request.setAttribute("TimeTable", list);
		 	        request.setAttribute("errorString", errorString);
			 	    request.setAttribute("Admin", Admin); 
		 		   	RequestDispatcher dispatcher = request.getServletContext()
			                   .getRequestDispatcher("/WEB-INF/views/timeTableView.jsp");
			           dispatcher.forward(request, response);
	 	        }				
	 		   	
	           }
		}
	}