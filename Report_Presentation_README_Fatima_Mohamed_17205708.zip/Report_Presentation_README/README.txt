Server: Tomcat v. 9
IDE: Eclipse Oxygen
Database Schema: MySQL Workbench
Languages: Java, MySQL, HTML